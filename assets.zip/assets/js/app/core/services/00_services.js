// Generic models angular module initialize.
(function() {
  'use strict';

  angular.module('frontend.core.services', []);
}());
