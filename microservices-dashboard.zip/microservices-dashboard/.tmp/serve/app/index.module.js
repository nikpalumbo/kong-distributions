/* global angular*/

(function() {
  'use strict';

  angular
    .module('microServicesGui', [
      'ui.router', 'mm.foundation', 'ui.sortable', 'msgGraph'
    ]);
})();
